<h1 align="center">
  <a href="https://github.com/Dreamyplayer/DANG/">
  <img src="https://discord.com/assets/b941bc1dfe379db6cc1f2acc5a612f41.png" alt="DANG" width="420"/></a><br>DANG: <br>Dreamy's Awesome Nitro Generator<br>
  <a href="https://discord.gg/CNAJfbs5dn"><img src="https://img.shields.io/discord/849280500421492736?color=5865F2&logo=discord&logoColor=white&style=plastic" alt="Discord server" /></a>
  <a href="https://github.com/Dreamyplayer"><img src="https://img.shields.io/github/stars/Dreamyplayer?color=white&logo=github&style=plastic" alt="Discord server" /></a>
  <a href="https://github.com/Dreamyplayer/DANG/blob/master/package.json"><img src="https://img.shields.io/github/package-json/v/Dreamyplayer/Discord-Nitro-Gen-and-Checker?color=l&logo=git&logoColor=lightgreen&style=plastic" alt="Discord server" /></a>
  <a href="https://paypal.me/DreamyPlayer"><img src="https://img.shields.io/badge/donate-paypal-blue"></a> 🥀
  <br><img src="https://cdn-icons-png.flaticon.com/512/5968/5968756.png"
  width="30"
  height="30"
  style="position:absolute;left: 240px;top:577px"><a title='Dreamy - Imagine a Database' href="https://discord.gg/CNAJfbs5dn">Join Our Discord<br></a>
  <a href="https://github.com/Dreamyplayer/DANG"><img src="https://cdn.discordapp.com/attachments/851533693657808926/857214104359534592/Screenshot_from_2021-06-23_16-32-21.png" /></a>
  <a href="https://github.com/Dreamyplayer/DANG"><img src="https://cdn.discordapp.com/attachments/851533693657808926/955707310796324885/Screenshot_from_2022-03-22_11-27-48.png" /></a>
</h1>

## 🌹 Features
- ⚡ Blazingly fast
- 🩸 Bleeding edge
- ✈️ Proxy support: http/s, socks4/5, Premium
- 🪶 Easy to use

## 🎮 Getting Started

Before, We start please follow these Steps: <kbd>Required*</kbd>

- ⭐ Give a Star to this [**dreamy-db**](https://github.com/Dreamyplayer/dreamy-db "dreamy-db") & [**Discord Nitro Generator and checker**](https://github.com/Dreamyplayer/DANG "Discord Nitro Generator & Checker")
- 🍴 Fork This Repository [**DANG.**](https://github.com/Dreamyplayer/DANG "DANG")
- 🔥 Join Our Discord Server [**Dreamy - Imagine a Database**](https://discord.gg/CNAJfbs5dn "Dreamy - Imagine a Database")

## 🧩 Prerequisites

- Download & Install [**Node.js**](https://nodejs.org/en/ 'nodejs')
- Download & Install [**Git**](https://git-scm.com/ 'Install Git') (Optional)
- Run <kbd>node -v</kbd> & <kbd>npm -v</kbd> in terminal
- Run These commands in terminal just to make sure node.js Installed and PATH added.
- If this returns/logs random number starting with <kbd>v</kbd> then All Good 👍
- If [**Git**](https://git-scm.com/ 'Git') not installed download code directly [**Here**](https://github.com/Dreamyplayer/DANG "Discord Ntro Gen & Checker").

## 🍀 Installation
- If Git is not installed Ignore [Installation](https://github.com/Dreamyplayer/DANG#installation) Step.
- Open <kbd>Folder</kbd> where you want to clone this repo
- Open terminal & Run below command.

```console
git clone https://github.com/Dreamyplayer/DANG.git
```

## ☕ Usage

- Open Project Folder (<kbd>./DANG/</kbd>)
- Open <kbd>Terminal</kbd>||<kbd>Console</kbd>||<kbd>CMD</kbd> (in same folder)
- Run <kbd>npm install</kbd> in terminal (and wait for installs to complete)
- Run <kbd>npm start</kbd> in terminal (to Start Discord Nitro Script)

## 👽 Configuration

- Open <kbd>config.js</kbd> file (./root/ or ./DANG/ folder).
- Length <kbd>24</kbd> Premium Nitro.
- Length <kbd>16</kbd> classic Nitro.
- Amount `10,000` is max set below.
- Change proxiesType [valid values] <kbd>http, socks4, socks5</kbd>  (optional)
> Keep all other settings values **default**.

## ✨ Contributing

1. 🍴 [Fork the repository](https://github.com/Dreamyplayer/DANG/fork)!
2. Clone your fork: <kbd>git clone https://github.com/your-username/DANG.git</kbd>
3. Create your feature branch: <kbd>git checkout -b my-new-feature</kbd>
4. Commit your changes: <kbd>git commit -am 'Add some feature'</kbd>
5. Push to the branch: <kbd>git push origin my-new-feature</kbd>
6. Submit a pull request 🤯

### 🧑‍⚖️ | ⚠️ License & Warning
- 🦩 Made for educational purposes and as a proof of concept and I do not take any responsibility for any bad usage.
- 📝 Licensed Under [Apache License 2.0](https://github.com/Dreamyplayer/DANG/blob/master/LICENSE) License.
---
<h2 align="center">© 2022 <a href="https://github.com/Dreamyplayer/">♔ Dяεαмү アlαүεя ♔<a> ✌️</h2>
